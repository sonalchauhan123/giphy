function myFunc (msg: string): string { 
    return 'I like to repeat what you said, therefore: ' + msg; 
} 

console.log(myFunc('hello'));
